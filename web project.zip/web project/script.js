// You can add interactive features here.
console.log('NewsLab site ready');

